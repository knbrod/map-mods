-- This mod was made for free by JRod and Larcius.
-- For more information check out https://www.gta5-mods.com/maps/forests-of-san-andreas-revised

fx_version "adamant"
game "gta5"

author 'Larcius'
description 'Forests of San Andreas (North): Revised'
version '5.1'

data_file('DLC_ITYP_REQUEST')('stream/forests_n_slod.ytyp')
